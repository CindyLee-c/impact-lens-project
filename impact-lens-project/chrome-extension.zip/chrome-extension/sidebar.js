// Sidebar functionality
document.addEventListener('DOMContentLoaded', function() {
  const analyzeBtn = document.getElementById('analyzeBtn');
  const loading = document.getElementById('loading');
  const results = document.getElementById('results');
  const error = document.getElementById('error');
  const noContent = document.getElementById('noContent');
  const usage = document.getElementById('usage');

  // Update usage display
  updateUsageDisplay();

  // Handle analyze button click
  analyzeBtn.addEventListener('click', async function() {
    try {
      showLoading();

      // Get current tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // Extract content from the current page
      const response = await chrome.tabs.sendMessage(tab.id, { action: 'extractContent' });

      if (!response || !response.text || response.text.length < 100) {
        throw new Error('Geen voldoende inhoud gevonden op deze pagina');
      }

      // Send to background for analysis
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
          action: 'analyzeContent',
          content: response
        }, (response) => {
          if (response.success) {
            resolve(response.data);
          } else {
            reject(new Error(response.error));
          }
        });
      });

      displayResults(result);
      updateUsageDisplay();

    } catch (err) {
      showError(err.message);
    }
  });

  function showLoading() {
    analyzeBtn.disabled = true;
    loading.style.display = 'block';
    results.style.display = 'none';
    error.style.display = 'none';
    noContent.style.display = 'none';
  }

  function hideLoading() {
    analyzeBtn.disabled = false;
    loading.style.display = 'none';
  }

  function showError(message) {
    hideLoading();
    error.textContent = message;
    error.style.display = 'block';
    results.style.display = 'none';
    noContent.style.display = 'none';
  }

  function displayResults(data) {
    hideLoading();

    // Display claim
    document.getElementById('claim').textContent = data.claim_summary || 'Geen claim gevonden';

    // Display questions
    const questionsList = document.getElementById('questions');
    questionsList.innerHTML = '';
    if (data.critical_questions && data.critical_questions.length > 0) {
      data.critical_questions.forEach(question => {
        const li = document.createElement('li');
        li.textContent = question;
        questionsList.appendChild(li);
      });
    }

    // Display impact points
    const impactList = document.getElementById('impactPoints');
    impactList.innerHTML = '';
    if (data.impact_summary && data.impact_summary.length > 0) {
      data.impact_summary.forEach(point => {
        const li = document.createElement('li');
        li.textContent = point;
        impactList.appendChild(li);
      });
    }

    // Display sources
    const sourcesDiv = document.getElementById('sources');
    if (data.sources && data.sources.length > 0) {
      sourcesDiv.innerHTML = '<strong>Bronnen:</strong> ' +
        data.sources.map(source =>
          `<a href="${source.url}" target="_blank">${source.title}</a>`
        ).join(', ');
    } else {
      sourcesDiv.innerHTML = '';
    }

    results.style.display = 'block';
    error.style.display = 'none';
    noContent.style.display = 'none';
  }

  async function updateUsageDisplay() {
    try {
      const { usage = { monthly: 0 } } = await chrome.storage.local.get('usage');
      usage.textContent = `${usage.monthly}/5 gebruikt`;
      const result = await chrome.storage.local.get({ usage: { monthly: 0 } });
      const usageData = result.usage;

      if (usage.monthly >= 5) {
        analyzeBtn.textContent = 'Limiet bereikt - Upgrade';
      usage.textContent = `${usageData.monthly}/5 gebruikt`;

      if (usageData.monthly >= 5) {
        analyzeBtn.disabled = true;
        analyzeBtn.textContent = 'Limiet bereikt';
        analyzeBtn.style.background = '#ea4335';
      }
    } catch (err) {
      console.error('Error updating usage:', err);
    }
  }

  // Check for existing analysis on load
  chrome.storage.local.get(['latestAnalysis', 'analysisTimestamp'], (result) => {
    if (result.latestAnalysis && result.analysisTimestamp) {
      const hourAgo = Date.now() - (60 * 60 * 1000);
      if (result.analysisTimestamp > hourAgo) {
        displayResults(result.latestAnalysis);
        return;
      }
    }
    noContent.style.display = 'block';
  });
});