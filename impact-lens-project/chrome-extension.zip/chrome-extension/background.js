// Background service worker
const API_BASE_URL = 'https://impact-lens-api-602723277830.europe-west1.run.app';

chrome.runtime.onInstalled.addListener(() => {
  console.log('Impact-Lens extension installed');
});

// Handle messages from content script and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'analyzeContent') {
    analyzeContent(request.content)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Keep the messaging channel open for async response
  }

  if (request.action === 'contentReady') {
    // Store content for sidebar access
    chrome.storage.local.set({
      latestContent: request.content,
      contentTimestamp: Date.now()
    });
  }

  if (request.action === 'openSidePanel') {
    chrome.sidePanel.open({ tabId: sender.tab.id });
  }
});

async function analyzeContent(content) {
  try {
    const response = await fetch(`${API_BASE_URL}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url: content.url,
        title: content.title,
        text: content.text
      })
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const result = await response.json();

    // Store result for sidebar
    chrome.storage.local.set({
      latestAnalysis: result,
      analysisTimestamp: Date.now()
    });

    return result;
  } catch (error) {
    console.error('Analysis failed:', error);
    throw error;
  }
}

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// Track usage for billing
async function trackUsage(wordCount) {
  const { usage = { monthly: 0, words: 0 } } = await chrome.storage.local.get('usage');

  const now = new Date();
  const currentMonth = `${now.getFullYear()}-${now.getMonth()}`;

  if (usage.month !== currentMonth) {
    usage.monthly = 0;
    usage.month = currentMonth;
  }

  usage.monthly += 1;
  usage.words += wordCount;

  await chrome.storage.local.set({ usage });
  return usage;
}